
from pathlib import Path
from src.experiments import run_all

if __name__=="__main__":
    tabs=run_all(Path("results"))
    print("HCAT v1 experiment suite complete.")
    for name,df in tabs.items():
        print(f"{name}: {len(df)} rows -> results/{name}.csv")
