
from src.hcat_core import *
from src.families import *

def test_parity_projections():
    for d in [3,4,5]:
        E=parity_envelope(d,0).feasible
        F=parity_envelope(d,1).feasible
        for k in range(1,d):
            assert projection_disagreement(E,F,d,k)==0.0
            assert max_marginal_tv(E,F,d,k)==0.0

def test_full_order_identifies():
    d=4
    E=parity_envelope(d,0).feasible
    R=natural_join_reconstruction(E,d,d)
    assert R==E

def test_metric_range():
    A=parity_envelope(4,0)
    B=parity_envelope(4,1)
    v=vector_distortion(A,B)
    assert all(0<=x<=1 for x in v.values())
    s=scalar_distortion(A,B)
    assert 0<=s<=1

def test_threshold_rank():
    assert threshold_rank({1:0.8,2:0.2,3:0.05},0.1)==3
