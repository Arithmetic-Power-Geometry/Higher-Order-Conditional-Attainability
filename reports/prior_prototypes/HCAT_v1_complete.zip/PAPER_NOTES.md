# Paper-ready mathematical and experimental plan

## Core definitions
Let E be a complete operational envelope and O_k(E) the collection of all
observations up to order k. For observational tolerance delta,

    [E]_{k,delta}
      = {F : d_obs(O_k(E),O_k(F)) <= delta}.

For a scalarization d_w of the native vector operational distortion,

    rho_{k,delta}(E)
      = sup_{F in [E]_{k,delta}} d_w(E,F),

    Omega_{k,delta}(E)
      = sup_{F,G in [E]_{k,delta}} d_w(F,G).

Define threshold rank

    r_A^tau(E) = min{k : Omega_{k,delta}(E) <= tau}.

Define observation-order selection

    k* = argmin_k [M(k) + lambda Omega_{k,delta}(E)].

## Theorems to prove in the manuscript
1. Nested observational classes under exact observation:
      [E]_{k+1} subseteq [E]_k.
2. Monotonicity:
      rho_{k+1}(E) <= rho_k(E),
      Omega_{k+1}(E) <= Omega_k(E).
3. Diameter-radius inequality:
      rho_k(E) <= Omega_k(E) <= 2 rho_k(E).
4. Finite parity maximum-opacity witness under task-only normalized set distance.
5. Approximate/noisy monotonicity under a nested observational discrepancy.
6. Decision bound:
   under an L-Lipschitz utility model, derive and prove an appropriate regret
   bound in terms of rho or Omega. Do NOT state a constant as a theorem until
   the proof assumptions are fixed.

## What is exact vs empirical in the software
The parity structural experiment is exact.
The broader rho/Omega values are candidate-bank lower bounds, not exact suprema.
This distinction should be explicit in the paper.

## Strong paper claim
Do not write "HCAT is better than existing mathematics."
Write:
"HCAT is designed to complement existing projection, marginal, and
reconstruction analyses by quantifying residual operational ambiguity after
bounded-order observation and by linking that ambiguity to observation-order
selection and robust decision making."
