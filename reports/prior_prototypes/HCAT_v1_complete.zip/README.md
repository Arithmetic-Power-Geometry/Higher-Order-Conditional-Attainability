# HCAT v1.0 Complete Research Prototype

This package implements the enhancement plan for **Higher-Order Conditional Attainability (HCAT)**.

## Included
- Native **vector operational distortion**:
  task, resource, error, condition, composition.
- Scalarization with explicit weights (secondary to the vector).
- Exact bounded-order projection and marginal baselines.
- Natural/lossless-join reconstruction baseline.
- Approximate observational classes `[E]_(k,delta)`.
- Reconstruction risk `rho_(k,delta)`.
- Opacity `Omega_(k,delta)`.
- Threshold rank `r_A^tau`.
- Observation-order optimizer `k* = argmin M(k)+lambda Omega_k`.
- Robust decision layer and decision regret.
- Synthetic families:
  parity, threshold, sparse XOR, noisy parity, hypergraph constraints.
- Ablation study.
- Noise robustness study.
- Scalability study.
- Unit tests.

## Important scientific boundary
The package does **not** claim parity, marginal non-identifiability, relational
join failure, symmetric difference, or local-to-global obstruction as new.
Those are established ideas. The proposed contribution under evaluation is
the operational hierarchy built from bounded-order observation classes,
vector distortion, opacity/risk, threshold rank, and decision-aware stopping.

## Run
```bash
python run_all.py
pytest -q
```

## Generated result files
- `results/parity_exact.csv`
- `results/operational_families.csv`
- `results/ablation.csv`
- `results/robustness.csv`
- `results/decision.csv`
- `results/scalability.csv`
- `results/method_benefit_comparison.csv`

## Exact parity sanity check
For every tested dimension d=3..6 and every proper order k<d:
- projection disagreement = 0,
- maximum marginal TV = 0,
- join reconstruction error = 0.5,
- task-only parity opacity witness = 1.

At k=d, full-order reconstruction becomes exact.

## Caution
Operational opacity in the broader synthetic experiments is computed over a
finite candidate bank, so it is an **empirical lower bound** on the supremum over
all globally compatible envelopes. The exact theorem-level object remains the
supremum over the full admissible class.
