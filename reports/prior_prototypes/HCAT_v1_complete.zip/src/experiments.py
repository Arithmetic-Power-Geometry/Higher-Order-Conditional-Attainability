
from __future__ import annotations
import argparse, time, random
import pandas as pd
from .hcat_core import *
from .families import *

def exact_parity_table(ds=(3,4,5,6)):
    rows=[]
    for d in ds:
        A=parity_envelope(d,0,1)
        B=parity_envelope(d,1,2)
        for k in range(1,d+1):
            # exact structural opacity under prototype task-only symdiff for parity
            exact_task_opacity = 1.0 if k<d else 0.0
            rows.append({
                "family":"parity","d":d,"k":k,
                "global_task_symdiff": normalized_symdiff(A.feasible,B.feasible,d),
                "projection_disagreement": projection_disagreement(A.feasible,B.feasible,d,k),
                "max_marginal_TV": max_marginal_tv(A.feasible,B.feasible,d,k),
                "join_error": join_reconstruction_error(A.feasible,d,k),
                "exact_task_opacity": exact_task_opacity,
                "exact_task_rank": d,
            })
    return pd.DataFrame(rows)

def operational_family_table(ds=(4,5,6),delta=0.05,tau=0.10):
    rows=[]
    families=[]
    for d in ds:
        families += [
            ("parity", parity_envelope(d,0,10+d)),
            ("threshold", threshold_envelope(d,max(1,d//2),20+d)),
            ("sparse_xor", sparse_xor_envelope(d,max(1,d//2),30+d)),
            ("noisy_parity_10", noisy_parity_envelope(d,0.10,40+d)),
            ("hypergraph", hypergraph_envelope(d,min(3,d),3,50+d)),
        ]
    for name,E in families:
        bank=candidate_bank(E.d,seed=500+E.d)
        # ensure target itself is in candidate class
        bank=[E]+bank
        op={}
        for k in range(1,E.d+1):
            rho,omega,nc=rho_omega_from_candidates(E,bank,k,delta)
            op[k]=omega
            rows.append({
                "family":name,"d":E.d,"k":k,"delta":delta,
                "rho":rho,"omega":omega,"compatible_candidates":nc,
                "join_error":join_reconstruction_error(E.feasible,E.d,k),
            })
        r=threshold_rank(op,tau)
        kstar,score,_=optimal_observation_order(op,lam=5.0,base=0.15,exponent=1.35)
        for row in rows[-E.d:]:
            row["threshold_tau"]=tau
            row["threshold_rank"]=r
            row["k_star"]=kstar
            row["k_star_objective"]=score
    return pd.DataFrame(rows)

def ablation_table(d=5,delta=0.05):
    E=hypergraph_envelope(d,3,3,909)
    bank=[E]+candidate_bank(d,910)
    weight_sets={
        "task_only":{"task":1,"resource":0,"error":0,"condition":0,"composition":0},
        "task_resource":{"task":0.6,"resource":0.4,"error":0,"condition":0,"composition":0},
        "task_resource_error":{"task":0.5,"resource":0.3,"error":0.2,"condition":0,"composition":0},
        "full":{"task":0.35,"resource":0.25,"error":0.15,"condition":0.10,"composition":0.15},
    }
    rows=[]
    for label,w in weight_sets.items():
        for k in range(1,d+1):
            rho,omega,nc=rho_omega_from_candidates(E,bank,k,delta,w)
            rows.append({"ablation":label,"d":d,"k":k,"rho":rho,"omega":omega,"compatible":nc})
    return pd.DataFrame(rows)

def robustness_table(d=5, reps=20, tau=0.10):
    rows=[]
    for p in [0,0.02,0.05,0.10,0.20]:
        ranks=[]
        aucs=[]
        for r in range(reps):
            E=noisy_parity_envelope(d,p,1000+100*r+int(100*p))
            bank=[E]+candidate_bank(d,2000+r)
            op={}
            for k in range(1,d+1):
                _,omega,_=rho_omega_from_candidates(E,bank,k,delta=0.08)
                op[k]=omega
            rank=threshold_rank(op,tau)
            auc=sum(op[k] for k in range(1,d))/max(1,d-1)
            ranks.append(rank if rank is not None else d+1)
            aucs.append(auc)
        rows.append({
            "noise_p":p,"d":d,"reps":reps,
            "mean_threshold_rank":sum(ranks)/len(ranks),
            "sd_threshold_rank":float(pd.Series(ranks).std(ddof=1)),
            "mean_opacity_auc":sum(aucs)/len(aucs),
            "sd_opacity_auc":float(pd.Series(aucs).std(ddof=1)),
        })
    return pd.DataFrame(rows)

def decision_table(d=5,delta=0.05,value=10.0):
    # candidate actions are all binary states
    actions=list(universe(d))
    rows=[]
    cases=[
        ("threshold",threshold_envelope(d,3,3001)),
        ("sparse_xor",sparse_xor_envelope(d,3,3002)),
        ("noisy_parity",noisy_parity_envelope(d,0.10,3003)),
        ("hypergraph",hypergraph_envelope(d,3,3,3004)),
    ]
    for name,E in cases:
        bank=[E]+candidate_bank(d,4000)
        # compare a naive natural-join action against HCAT robust action at k=2,3
        true_action,true_u=true_best_action(E,actions,value)
        for k in [1,2,3]:
            R=natural_join_reconstruction(E.feasible,d,k)
            # "join baseline": choose cheapest action declared feasible by reconstructed relation
            feasible_actions=list(R) if R else actions
            join_action=min(feasible_actions,key=lambda a:E.cost.get(a,999))
            join_reg=decision_regret(E,join_action,actions,value)

            C=approximate_class(bank,E,k,delta)
            hcat_action,_=robust_action(C,actions,value)
            hcat_reg=decision_regret(E,hcat_action,actions,value)
            rho,omega,nc=rho_omega_from_candidates(E,bank,k,delta)
            rows.append({
                "family":name,"d":d,"k":k,
                "join_regret":join_reg,
                "hcat_robust_regret":hcat_reg,
                "rho":rho,"omega":omega,
                "compatible_candidates":nc,
                "true_best_utility":true_u,
            })
    return pd.DataFrame(rows)

def scalability_table(max_d=12):
    rows=[]
    for d in range(3,max_d+1):
        E=threshold_envelope(d,max(1,d//2),800+d)
        for k in [1,min(2,d),min(3,d)]:
            t0=time.perf_counter()
            _=join_reconstruction_error(E.feasible,d,k)
            elapsed=time.perf_counter()-t0
            rows.append({"d":d,"k":k,"universe_size":2**d,
                         "join_runtime_seconds":elapsed})
    return pd.DataFrame(rows)

def run_all(outdir):
    outdir.mkdir(parents=True,exist_ok=True)
    tabs={
        "parity_exact": exact_parity_table(),
        "operational_families": operational_family_table(),
        "ablation": ablation_table(),
        "robustness": robustness_table(),
        "decision": decision_table(),
        "scalability": scalability_table(),
    }
    for name,df in tabs.items():
        df.to_csv(outdir/f"{name}.csv",index=False)
    return tabs

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--outdir",default="results")
    args=p.parse_args()
    from pathlib import Path
    tabs=run_all(Path(args.outdir))
    for name,df in tabs.items():
        print("\n###",name)
        print(df.head(20).to_string(index=False))

if __name__=="__main__":
    main()
