
from __future__ import annotations
import random, math
from typing import Tuple, List
from .hcat_core import *

def _decorate(d:int,E:Relation,seed:int=0,resource_shift:float=0.0)->OperationalEnvelope:
    rng=random.Random(seed)
    U=universe(d)
    cost={}
    error={}
    condition={}
    composition={}
    for x in U:
        ones=sum(x)
        base=1.0+0.65*ones+0.15*(ones**2)
        # interaction-sensitive values, normalized to reasonable range
        interaction=(1 if (ones%2)==0 else 0)
        cost[x]=base+resource_shift*(0.5+0.5*interaction)
        error[x]=min(1.0, 0.03+0.025*ones + 0.08*(x in E) + 0.01*rng.random())
        condition[x]=min(1.0, 0.15+0.12*ones/d + 0.25*interaction)
        composition[x]=min(1.0, 0.10+0.08*ones + 0.22*interaction)
    return OperationalEnvelope(d,E,cost,error,condition,composition)

def parity_envelope(d:int, parity:int=0,seed:int=0)->OperationalEnvelope:
    E=frozenset(x for x in universe(d) if sum(x)%2==parity)
    return _decorate(d,E,seed,resource_shift=0.35*parity)

def threshold_envelope(d:int,q:int,seed:int=0)->OperationalEnvelope:
    E=frozenset(x for x in universe(d) if sum(x)>=q)
    return _decorate(d,E,seed)

def sparse_xor_envelope(d:int,order:int,seed:int=0)->OperationalEnvelope:
    # x_last must equal xor(first 'order' coordinates), remaining coords free
    order=min(order,d-1)
    E=frozenset(x for x in universe(d)
                if x[-1] == (sum(x[:order])%2))
    return _decorate(d,E,seed)

def noisy_parity_envelope(d:int,p:float,seed:int=0)->OperationalEnvelope:
    rng=random.Random(seed)
    base=set(x for x in universe(d) if sum(x)%2==0)
    E=set(base)
    for x in universe(d):
        if rng.random()<p:
            if x in E: E.remove(x)
            else: E.add(x)
    return _decorate(d,frozenset(E),seed)

def hypergraph_envelope(d:int,order:int,n_constraints:int=3,seed:int=0)->OperationalEnvelope:
    rng=random.Random(seed)
    idx=list(range(d))
    constraints=[]
    for _ in range(n_constraints):
        S=tuple(sorted(rng.sample(idx,min(order,d))))
        parity=rng.randint(0,1)
        constraints.append((S,parity))
    E=frozenset(x for x in universe(d)
                if all(sum(x[i] for i in S)%2==p for S,p in constraints))
    if not E:
        # safe fallback to one generated state satisfying a deterministic relaxed rule
        E=frozenset([tuple(0 for _ in range(d))])
    return _decorate(d,E,seed)

def candidate_bank(d:int,seed:int=0)->List[OperationalEnvelope]:
    bank=[]
    bank += [parity_envelope(d,0,seed), parity_envelope(d,1,seed+1)]
    for q in range(1,d+1):
        bank.append(threshold_envelope(d,q,seed+10+q))
    for o in range(1,d):
        bank.append(sparse_xor_envelope(d,o,seed+30+o))
    for p in [0.02,0.05,0.10,0.20]:
        for r in range(3):
            bank.append(noisy_parity_envelope(d,p,seed+100+r+int(100*p)))
    for o in range(2,min(d,5)+1):
        for r in range(3):
            bank.append(hypergraph_envelope(d,o,3,seed+200+10*o+r))
    # deduplicate by feasible relation + rounded decorations rough identity
    seen=set(); uniq=[]
    for E in bank:
        key=(E.feasible, tuple(round(E.cost[x],6) for x in universe(d)))
        if key not in seen:
            seen.add(key); uniq.append(E)
    return uniq
