
from __future__ import annotations
from dataclasses import dataclass
from itertools import product, combinations
from typing import Dict, Tuple, FrozenSet, Iterable, List, Optional
import math
import random
import numpy as np

State = Tuple[int, ...]
Relation = FrozenSet[State]

def universe(d:int) -> Tuple[State,...]:
    return tuple(product((0,1), repeat=d))

def subsets_upto_k(d:int, k:int):
    return tuple(S for r in range(1,k+1) for S in combinations(range(d), r))

def projection(E:Relation, S:Tuple[int,...]):
    return frozenset(tuple(x[i] for i in S) for x in E)

def observation_signature(E:Relation, d:int, k:int):
    return tuple((S, tuple(sorted(projection(E,S)))) for S in subsets_upto_k(d,k))

def projection_disagreement(E:Relation, F:Relation, d:int, k:int) -> float:
    subs = subsets_upto_k(d,k)
    return sum(projection(E,S)!=projection(F,S) for S in subs)/len(subs)

def normalized_symdiff(E:Relation, F:Relation, d:int) -> float:
    return len(E.symmetric_difference(F))/(2**d)

def natural_join_reconstruction(E:Relation, d:int, k:int) -> Relation:
    subs = subsets_upto_k(d,k)
    ps = {S: projection(E,S) for S in subs}
    return frozenset(x for x in universe(d)
                     if all(tuple(x[i] for i in S) in ps[S] for S in subs))

def join_reconstruction_error(E:Relation, d:int, k:int) -> float:
    return normalized_symdiff(E, natural_join_reconstruction(E,d,k), d)

def uniform_marginal(E:Relation, S:Tuple[int,...]):
    if not E:
        return {}
    counts={}
    for x in E:
        z=tuple(x[i] for i in S)
        counts[z]=counts.get(z,0)+1
    n=len(E)
    return {z:c/n for z,c in counts.items()}

def total_variation(p:dict,q:dict)->float:
    keys=set(p)|set(q)
    return 0.5*sum(abs(p.get(z,0)-q.get(z,0)) for z in keys)

def max_marginal_tv(E:Relation,F:Relation,d:int,k:int)->float:
    return max((total_variation(uniform_marginal(E,S),uniform_marginal(F,S))
                for S in subsets_upto_k(d,k)), default=0.0)

@dataclass(frozen=True)
class OperationalEnvelope:
    d: int
    feasible: Relation
    cost: Dict[State,float]
    error: Dict[State,float]
    condition: Dict[State,float]
    composition: Dict[State,float]

def _avg_abs_component(A:OperationalEnvelope,B:OperationalEnvelope, field:str) -> float:
    U=universe(A.d)
    a=getattr(A,field); b=getattr(B,field)
    vals=[]
    for x in U:
        va=a.get(x,1.0 if field!="cost" else 1.0)
        vb=b.get(x,1.0 if field!="cost" else 1.0)
        if field=="cost":
            den=max(abs(va),abs(vb),1e-12)
            vals.append(abs(va-vb)/den)
        else:
            vals.append(abs(va-vb))
    return float(np.mean(vals))

def vector_distortion(A:OperationalEnvelope,B:OperationalEnvelope):
    assert A.d==B.d
    return {
        "task": normalized_symdiff(A.feasible,B.feasible,A.d),
        "resource": _avg_abs_component(A,B,"cost"),
        "error": _avg_abs_component(A,B,"error"),
        "condition": _avg_abs_component(A,B,"condition"),
        "composition": _avg_abs_component(A,B,"composition"),
    }

def scalar_distortion(A:OperationalEnvelope,B:OperationalEnvelope,
                      weights=None)->float:
    if weights is None:
        weights={"task":0.35,"resource":0.25,"error":0.15,"condition":0.10,"composition":0.15}
    v=vector_distortion(A,B)
    sw=sum(weights.values())
    return sum(weights[k]*v[k] for k in weights)/sw

def observed_distance(E:Relation,F:Relation,d:int,k:int)->float:
    # hybrid relational observational discrepancy in [0,1]
    return 0.5*projection_disagreement(E,F,d,k)+0.5*max_marginal_tv(E,F,d,k)

def approximate_class(candidates:Iterable[OperationalEnvelope],
                      target:OperationalEnvelope,k:int,delta:float):
    out=[]
    for F in candidates:
        if F.d!=target.d: 
            continue
        if observed_distance(target.feasible,F.feasible,target.d,k) <= delta+1e-12:
            out.append(F)
    return out

def rho_omega_from_candidates(target:OperationalEnvelope,
                              candidates:Iterable[OperationalEnvelope],
                              k:int,delta:float=0.0,weights=None):
    C=approximate_class(candidates,target,k,delta)
    if not C:
        return 0.0,0.0,0
    rho=max(scalar_distortion(target,F,weights) for F in C)
    omega=0.0
    for i,F in enumerate(C):
        for G in C[i:]:
            omega=max(omega,scalar_distortion(F,G,weights))
    return rho,omega,len(C)

def threshold_rank(opacity_by_k:Dict[int,float], tau:float)->Optional[int]:
    for k in sorted(opacity_by_k):
        if opacity_by_k[k] <= tau:
            return k
    return None

def observation_cost(k:int, base:float=1.0, exponent:float=1.5)->float:
    return base*(k**exponent)

def optimal_observation_order(opacity_by_k:Dict[int,float], lam:float=5.0,
                              base:float=1.0, exponent:float=1.5):
    scores={k:observation_cost(k,base,exponent)+lam*v for k,v in opacity_by_k.items()}
    kstar=min(scores,key=scores.get)
    return kstar,scores[kstar],scores

def robust_action(candidates:List[OperationalEnvelope], actions:List[State],
                  value:float=10.0):
    # maximin utility: success gives value-cost, failure gives -cost
    best=None; best_u=-1e18
    for a in actions:
        vals=[]
        for E in candidates:
            c=E.cost.get(a,1.0)
            success=a in E.feasible
            vals.append((value if success else 0.0)-c)
        u=min(vals) if vals else -1e18
        if u>best_u:
            best_u=u; best=a
    return best,best_u

def true_best_action(E:OperationalEnvelope, actions:List[State], value:float=10.0):
    best=None; best_u=-1e18
    for a in actions:
        c=E.cost.get(a,1.0)
        u=(value if a in E.feasible else 0.0)-c
        if u>best_u:
            best_u=u; best=a
    return best,best_u

def decision_regret(trueE:OperationalEnvelope, chosen:State, actions:List[State],
                    value:float=10.0):
    _,uopt=true_best_action(trueE,actions,value)
    c=trueE.cost.get(chosen,1.0)
    uchosen=(value if chosen in trueE.feasible else 0.0)-c
    return max(0.0,uopt-uchosen)
