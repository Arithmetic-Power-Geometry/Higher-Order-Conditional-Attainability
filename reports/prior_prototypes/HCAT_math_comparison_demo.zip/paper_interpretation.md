# Paper-ready interpretation

The comparison deliberately separates known mathematics from the proposed layer.

Known baselines answer:
1. Are two complete relations globally different?
2. Do their bounded-order projections differ?
3. Does joining bounded-order projections recover the original relation?
4. Do bounded-order probability marginals differ?

The proposed HCAT layer asks a different quantitative question:
After *all* observations up to order k have been fixed, how much global
operational ambiguity can still remain?

rho_k(E) measures worst reconstruction risk relative to E.
Omega_k(E) measures the diameter of the whole compatible global class.
r_A(E) is the first order at which the ambiguity vanishes.

On parity envelopes, all proper-order projection and marginal comparisons are
zero, natural-join reconstruction has 0.5 normalized error, while HCAT opacity
remains maximal (1.0) until full order d and then drops to zero.
