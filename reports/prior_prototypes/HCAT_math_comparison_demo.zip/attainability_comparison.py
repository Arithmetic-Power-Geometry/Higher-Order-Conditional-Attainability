
"""
attainability_comparison.py

Finite prototype comparing proposed Higher-Order Conditional Attainability
(HCAT) quantities against nearby mathematical baselines.

The demonstration uses even/odd parity relations on {0,1}^d.

Baselines:
  1) full-set normalized symmetric difference
  2) <=k coordinate-projection disagreement
  3) natural-join reconstruction error
  4) <=k uniform-marginal total-variation distance

Proposed prototype:
  rho_k(E)   = max distance from E to a globally compatible relation
  Omega_k(E) = diameter of the <=k observational equivalence class
  r_A(E)     = minimum k with Omega_k(E)=0

For the parity family, exact rho/Omega values can be certified without an
expensive all-pairs search: the odd-parity relation is the complement of the
even-parity relation, has identical every-proper projection, and is distance 1.
At full order the observational class is a singleton.

The prototype metric is normalized symmetric difference. This is intentionally
simple and is NOT claimed as the final resource/error-aware HCAT metric.
"""

from itertools import product, combinations
from collections import defaultdict
import argparse, csv

def universe(d):
    return tuple(product((0, 1), repeat=d))

def parity_relation(d, parity=0):
    return frozenset(x for x in universe(d) if sum(x) % 2 == parity)

def subsets_upto_k(d, k):
    return tuple(S for r in range(1, k+1) for S in combinations(range(d), r))

def projection(E, S):
    return frozenset(tuple(x[i] for i in S) for x in E)

def normalized_symmetric_difference(E, F, d):
    return len(E.symmetric_difference(F)) / (2 ** d)

def projection_disagreement(E, F, d, k):
    subs = subsets_upto_k(d, k)
    return sum(projection(E,S) != projection(F,S) for S in subs) / len(subs)

def natural_join_reconstruction(E, d, k):
    subs = subsets_upto_k(d, k)
    Ps = {S: projection(E,S) for S in subs}
    return frozenset(
        x for x in universe(d)
        if all(tuple(x[i] for i in S) in Ps[S] for S in subs)
    )

def join_reconstruction_error(E, d, k):
    R = natural_join_reconstruction(E,d,k)
    return normalized_symmetric_difference(E,R,d)

def uniform_marginal(E, S):
    counts = defaultdict(int)
    for x in E:
        counts[tuple(x[i] for i in S)] += 1
    n = len(E)
    return {z:c/n for z,c in counts.items()}

def tv(p,q):
    keys = set(p) | set(q)
    return 0.5 * sum(abs(p.get(z,0)-q.get(z,0)) for z in keys)

def max_marginal_tv(E,F,d,k):
    return max(
        tv(uniform_marginal(E,S), uniform_marginal(F,S))
        for S in subsets_upto_k(d,k)
    )

def same_observations(E,F,d,k):
    return all(projection(E,S)==projection(F,S) for S in subsets_upto_k(d,k))

def parity_hcat_exact(d,k):
    """
    Exact HCAT prototype values for E=even parity.
    For k<d, odd parity is a compatible complement:
      d_A(E,F)=1, and normalized distance cannot exceed 1.
      Hence rho_k=Omega_k=1 exactly.
    For k=d, full projection identifies E exactly, hence rho=Omega=0.
    """
    E = parity_relation(d,0)
    F = parity_relation(d,1)
    if k < d:
        assert same_observations(E,F,d,k)
        assert abs(normalized_symmetric_difference(E,F,d)-1.0) < 1e-12
        return 1.0, 1.0
    return 0.0, 0.0

def parity_rank(d):
    return d

def evaluate(d):
    E = parity_relation(d,0)
    F = parity_relation(d,1)
    rows=[]
    for k in range(1,d+1):
        rho,omega = parity_hcat_exact(d,k)
        rows.append({
            "d": d,
            "k": k,
            "global_symdiff_E_vs_F": normalized_symmetric_difference(E,F,d),
            "projection_disagreement": projection_disagreement(E,F,d,k),
            "max_marginal_TV": max_marginal_tv(E,F,d,k),
            "join_reconstruction_error_E": join_reconstruction_error(E,d,k),
            "HCAT_rho_k": rho,
            "HCAT_Omega_k": omega,
            "HCAT_rank_rA": parity_rank(d),
        })
    return rows

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--dimensions", nargs="+", type=int, default=[3,4,5,6])
    p.add_argument("--csv", default="results.csv")
    args=p.parse_args()

    rows=[]
    for d in args.dimensions:
        rows.extend(evaluate(d))

    with open(args.csv,"w",newline="") as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    print("d k | global | proj.diff | marg.TV | join.err | rho | Omega | rank")
    print("-"*74)
    for r in rows:
        print(
            f"{r['d']:1d} {r['k']:1d} | "
            f"{r['global_symdiff_E_vs_F']:.3f}  | "
            f"{r['projection_disagreement']:.3f}     | "
            f"{r['max_marginal_TV']:.3f}   | "
            f"{r['join_reconstruction_error_E']:.3f}    | "
            f"{r['HCAT_rho_k']:.3f} | "
            f"{r['HCAT_Omega_k']:.3f} | "
            f"{r['HCAT_rank_rA']}"
        )

if __name__=="__main__":
    main()
