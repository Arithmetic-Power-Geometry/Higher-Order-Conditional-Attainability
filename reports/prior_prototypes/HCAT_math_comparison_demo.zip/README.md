# HCAT finite mathematical comparison demo

This is a research prototype comparing proposed Higher-Order Conditional
Attainability (HCAT) quantities with nearby finite baselines.

## Run
`python attainability_comparison.py --dimensions 3 4 5 6 --csv results.csv`

## Demonstration
For d binary coordinates:

E0 = {x : sum(x) mod 2 = 0}
E1 = {x : sum(x) mod 2 = 1}

For every k<d, all <=k coordinate projections of E0 and E1 are identical.
Their corresponding uniform marginals are also identical, but E0 and E1 are
globally disjoint.

The script reports:
- full normalized symmetric difference;
- <=k projection disagreement;
- <=k maximum marginal TV;
- natural-join reconstruction error;
- proposed rho_k;
- proposed Omega_k;
- proposed attainability rank r_A.

For the parity family, rho_k=Omega_k=1 for k<d is exact because E1 is both
(i) observationally compatible with E0 at every proper order and
(ii) its complement, hence normalized symmetric-difference distance 1.
At k=d, full observation identifies E0 exactly and opacity is 0.

## Important research boundary
The parity/local-global phenomenon is classical and is not claimed as new.
Normalized symmetric difference is also standard.

The candidate contribution being tested is the *derived operational summary*:
a hierarchy of bounded-order observational classes, their residual diameter
Omega_k, reconstruction risk rho_k, and the minimum sufficient order r_A.

For a publishable theory, the next version should replace the prototype
symmetric-difference metric by a native task/resource/error/composition-aware
distortion and verify that the opacity/rank results remain informative.
