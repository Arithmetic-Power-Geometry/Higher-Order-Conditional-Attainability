
import numpy as np, pandas as pd
from .hcat_core import *
from .families import *
from .decision_theory import *

def small_bank(d,seed):
    return [
        parity_envelope(d,0,seed), parity_envelope(d,1,seed+1),
        threshold_envelope(d,1,seed+2), threshold_envelope(d,2,seed+3),
        threshold_envelope(d,3,seed+4),
        sparse_xor_envelope(d,1,seed+5), sparse_xor_envelope(d,2,seed+6),
        noisy_parity_envelope(d,0.05,seed+7),
        noisy_parity_envelope(d,0.10,seed+8),
        hypergraph_envelope(d,2,2,seed+9),
        hypergraph_envelope(d,3,2,seed+10),
    ]

def class_for(E,bank,k,delta):
    C=approximate_class(bank,E,k,delta)
    if not any(F is E for F in C): C=[E]+C
    return C

def decision_experiment(d=4,reps=20,delta=0.05,reward=10.0):
    makers=[
        ("threshold",lambda s:threshold_envelope(d,2,s)),
        ("sparse_xor",lambda s:sparse_xor_envelope(d,2,s)),
        ("noisy_parity",lambda s:noisy_parity_envelope(d,0.10,s)),
        ("hypergraph",lambda s:hypergraph_envelope(d,3,2,s)),
    ]
    rows=[]
    for name,maker in makers:
        for rep in range(reps):
            E=maker(1000+rep)
            bank=[E]+small_bank(d,2000+rep)
            for k in [1,2,3]:
                C=class_for(E,bank,k,delta)
                r,rho,om,b1,b2=theorem_bound(E,C,reward)
                R=natural_join_reconstruction(E.feasible,d,k)
                acts=list(R) if R else list(universe(d))
                a_join=min(acts,key=lambda a:E.cost.get(a,999))
                rows.append({
                    "family":name,"rep":rep,"k":k,
                    "join_regret":regret(E,a_join,reward),
                    "hcat_regret":r,"rho_U":rho,"Omega_U":om,
                    "rho_bound_holds":b1,"omega_bound_holds":b2,
                    "class_size":len(C)
                })
    return pd.DataFrame(rows)

def real_data_audit():
    from sklearn.datasets import load_breast_cancer
    data=load_breast_cancer()
    X=np.asarray(data.data,float); y=np.asarray(data.target,int)
    corrs=np.array([abs(np.corrcoef(X[:,j],y)[0,1]) for j in range(X.shape[1])])
    idx=np.argsort(np.nan_to_num(corrs))[-5:][::-1]
    med=np.median(X[:,idx],axis=0)
    B=(X[:,idx]>med).astype(int)
    E=frozenset(tuple(list(B[i])+[int(y[i])]) for i in range(len(y)))
    d=6
    rows=[]
    for k in range(1,d+1):
        R=natural_join_reconstruction(E,d,k)
        rows.append({
            "k":k,"n_samples":len(y),"observed_states":len(E),
            "reconstructed_states":len(R),
            "join_reconstruction_error":normalized_symdiff(E,R,d),
            "features":";".join(data.feature_names[j] for j in idx)
        })
    return pd.DataFrame(rows)

def parity_exact():
    rows=[]
    for d in [3,4,5,6]:
        A=parity_envelope(d,0,1); B=parity_envelope(d,1,2)
        for k in range(1,d+1):
            rows.append({
                "d":d,"k":k,
                "projection_disagreement":projection_disagreement(A.feasible,B.feasible,d,k),
                "max_marginal_TV":max_marginal_tv(A.feasible,B.feasible,d,k),
                "join_error":join_reconstruction_error(A.feasible,d,k),
                "exact_task_opacity_witness":1.0 if k<d else 0.0
            })
    return pd.DataFrame(rows)
