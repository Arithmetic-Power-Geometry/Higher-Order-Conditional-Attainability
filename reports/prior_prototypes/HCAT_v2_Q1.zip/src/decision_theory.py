
from .hcat_core import universe
def utility(E,a,reward=10.0):
    return (reward if a in E.feasible else 0.0)-E.cost.get(a,1.0)
def utility_distance(E,F,reward=10.0):
    return max(abs(utility(E,a,reward)-utility(F,a,reward)) for a in universe(E.d))/max(reward,1.0)
def rho_utility(E,C,reward=10.0):
    return max((utility_distance(E,F,reward) for F in C),default=0.0)
def omega_utility(C,reward=10.0):
    return max((utility_distance(F,G,reward) for F in C for G in C),default=0.0)
def robust_action(C,reward=10.0):
    acts=list(universe(C[0].d))
    return max(acts,key=lambda a:min(utility(F,a,reward) for F in C))
def optimal_action(E,reward=10.0):
    acts=list(universe(E.d))
    return max(acts,key=lambda a:utility(E,a,reward))
def regret(E,a,reward=10.0):
    a0=optimal_action(E,reward)
    return max(0.0,utility(E,a0,reward)-utility(E,a,reward))
def theorem_bound(E,C,reward=10.0):
    a=robust_action(C,reward)
    r=regret(E,a,reward)
    rho=rho_utility(E,C,reward)
    om=omega_utility(C,reward)
    return r,rho,om,(r<=reward*rho+1e-10),(r<=reward*om+1e-10)
