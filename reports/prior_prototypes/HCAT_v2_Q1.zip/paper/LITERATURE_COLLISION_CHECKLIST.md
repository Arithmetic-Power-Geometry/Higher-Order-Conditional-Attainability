Compare explicitly against relational consistency/CSP width/database joins,
marginal consistency and contextuality, approximate simulation/bisimulation,
higher-order information/PID/interaction hierarchies, and robust optimization.
Do not claim universal superiority.
