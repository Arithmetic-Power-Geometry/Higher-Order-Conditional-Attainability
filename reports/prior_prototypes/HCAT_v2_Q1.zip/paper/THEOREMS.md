# HCAT theorem core

Let \(C=[E]_{k,\delta}\) be the class of envelopes compatible with all
bounded-order observations up to tolerance \(\delta\).

Define the normalized utility pseudometric
\[
d_U(E,F)=S^{-1}\sup_a |u_E(a)-u_F(a)|.
\]

Define
\[
\rho_C(E)=\sup_{F\in C}d_U(E,F),\qquad
\Omega(C)=\sup_{F,G\in C}d_U(F,G).
\]

For exact observations, nested classes imply
\[
[E]_{k+1,0}\subseteq[E]_{k,0},
\]
hence exact \(\rho_k\) and \(\Omega_k\) are non-increasing.

Because \(E\in C\),
\[
\boxed{\rho_C(E)\le \Omega(C)\le 2\rho_C(E).}
\]

## Robust-decision regret theorem
Assume
\[
|u_E(a)-u_F(a)|\le Ld(E,F)
\]
for every action \(a\) and \(F\in C\). Let
\[
\hat a\in\arg\max_a\inf_{F\in C}u_F(a)
\]
and \(a^\star\in\arg\max_a u_E(a)\). Then
\[
\boxed{\operatorname{Regret}_E(\hat a)\le L\rho_C(E)\le L\Omega(C).}
\]

Proof: for all \(F\in C\),
\(u_F(a^\star)\ge u_E(a^\star)-L\rho_C(E)\).
Maximin optimality gives the same lower bound for the worst-case utility of
\(\hat a\), and because \(E\in C\), its true utility is at least that worst-case
utility. Rearrangement proves the result.

For \(d_U\), one may take \(L=S\).

Novelty caution: the inequality uses standard metric/robust reasoning.
The proposed contribution is its integration with bounded-order attainability
classes, opacity, threshold rank, and observation-order selection. Historical
novelty requires theorem-by-theorem literature checking.
