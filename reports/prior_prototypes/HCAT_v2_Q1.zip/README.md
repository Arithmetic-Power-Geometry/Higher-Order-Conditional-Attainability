# HCAT v2 Q1-strengthening package

Adds a utility pseudometric, a proved robust-decision regret bound, repeated
synthetic comparisons, exact parity sanity checks, a real-data structural audit,
tests, and a literature-collision checklist.

Run:
python run_q1_suite.py
python -m pytest -q

The real-data audit is structural only and is not a clinical decision system.
