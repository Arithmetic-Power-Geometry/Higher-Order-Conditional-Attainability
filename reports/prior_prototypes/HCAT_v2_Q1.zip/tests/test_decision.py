
from src.families import threshold_envelope, parity_envelope
from src.decision_theory import utility_distance, theorem_bound
def test_triangle():
    A=threshold_envelope(4,2,1); B=threshold_envelope(4,3,2); C=threshold_envelope(4,4,3)
    assert utility_distance(A,C)<=utility_distance(A,B)+utility_distance(B,C)+1e-12
def test_bound():
    E=threshold_envelope(4,2,1)
    C=[E,threshold_envelope(4,3,2),parity_envelope(4,0,3)]
    assert theorem_bound(E,C)[3] and theorem_bound(E,C)[4]
