
from pathlib import Path
import pandas as pd
from src.q1_experiments import decision_experiment, real_data_audit, parity_exact
out=Path("results"); out.mkdir(exist_ok=True)
d=decision_experiment(); d.to_csv(out/"decision_repeated.csv",index=False)
s=d.groupby(["family","k"]).agg(
 n=("rep","count"),
 join_regret_mean=("join_regret","mean"),
 hcat_regret_mean=("hcat_regret","mean"),
 rho_U_mean=("rho_U","mean"),
 Omega_U_mean=("Omega_U","mean"),
 rho_bound_pass_rate=("rho_bound_holds","mean"),
 omega_bound_pass_rate=("omega_bound_holds","mean")
).reset_index()
s.to_csv(out/"decision_summary.csv",index=False)
real=real_data_audit(); real.to_csv(out/"real_data_audit.csv",index=False)
p=parity_exact(); p.to_csv(out/"parity_exact.csv",index=False)
print("done",len(d),len(real),len(p))
